const conectar=require('../db_conexion.js');
const {Router} = require('express');
const router = Router();

const products=[
{id:1, name:'product1'},
{id:2, name:'product2'},
{id:3, name:'product3'}
]

router.get ('/api/product', (req, res) => {
    conectar.query('select id_producto,producto,costo from productos;', (error,filas)=>{
        if(error){
            res.status(403).send('Error en productos');
        }else{
            res.json(filas);
        }
    });
    
    
});

router.get ('/api/user', (req, res) => {
    conectar.query('select id_usuarios,user from usuarios;', (error,filas)=>{
        if(error){
            res.status(403).send('Error en usuarios');
        }else{
            res.json(filas);
        }
    });
    
    
});

router.get ('/api/platform', (req, res) => {
    conectar.query('select id_plataforma,Plataforma from plataformas;', (error,filas)=>{
        if(error){
            res.status(403).send('Error en Plataformas');
        }else{
            res.json(filas);
        }
    });
    
    
});

router.get ('/api/coin', (req, res) => {
    conectar.query('select id_Moneda,Moneda from monedas;', (error,filas)=>{
        if(error){
            res.status(403).send('Error en Monedas');
        }else{
            res.json(filas);
        }
    });
    
    
});


router.get ('/api/product/:id', (req, res) => {
    const productos=products.find(c=>c.id===parseInt(req.params.id));
    if(!productos) res.status(403).send('The product with the given ID was not found.');
    res.send(productos);
  });

router.post ('/api/product', (req, res) => {
    const producto = {
        id: products.length + 1,
        name: req.body.name
    };
    products.push(producto);
    res.send(producto);
});

router.put ('/api/product/:id', (req, res) => {
    const producto = products.find(c => c.id === parseInt(req.params.id));
    if (!producto) res.status(403).send('The product with the given ID was not found.');
    producto.name = req.body.name;
    res.send(producto);
});

router.delete ('/api/product/:id', (req, res) => {
    const producto = products.find(c => c.id === parseInt(req.params.id));
    if (!producto) res.status(403).send('The product with the given ID was not found.');
    const index = products.indexOf(producto);
    products.splice(index, 1);
    res.send(producto);
});



module.exports = router;