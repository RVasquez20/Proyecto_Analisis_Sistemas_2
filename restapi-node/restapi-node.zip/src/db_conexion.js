const mysql=require('mysql');
const conectar=mysql.createConnection({
    host:'localhost',
    user:'usr_so',
    password:'1234',
    database:'so'
});
conectar.connect(function(error){
    if(error){
        throw error;
    }else{
        console.log('Conexion exitosa');
    }
});
module.exports=conectar;